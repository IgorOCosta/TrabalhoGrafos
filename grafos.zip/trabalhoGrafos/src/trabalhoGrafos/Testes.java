package trabalhoGrafos;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class Testes {
	static Grafo g = new Grafo();
	
	@BeforeAll
	 public static void setup() {

		g.addVertice("1");
		g.addVertice("2");
		g.addVertice("3");
		g.addVertice("4");

		g.addAresta(0, "1", "2", false);
		g.addAresta(0, "2", "3", false);
		g.addAresta(0, "3", "1", false);


	}

	
	@Test
	void testExercicio1() {
		System.out.println("Exercicio 1");
		var resposta = g.isAdjacente(g.acharVertice("1"), g.acharVertice("2"));
		System.out.println(resposta);
	}

	
	@Test
	void testExercicio2() {
		System.out.println("Exercicio 2");
		var resposta = g.getGrau(g.acharVertice("1"));
		System.out.println(resposta);
	}
	
	@Test
	void testExercicio3() {
		System.out.println("Exercicio 3");
		var resposta = g.isRegular(this.g);
		System.out.println(resposta);
	}
	
	@Test
	void testExercicio4() {
		System.out.println("Exercicio 4");
		var resposta = g.isIsolado(g.acharVertice("1"));
		System.out.println(resposta);
	}

	@Test
	void testExercicio5() {
		System.out.println("Exercicio 5");
		var resposta = g.isIsolado(g.acharVertice("1"));
		System.out.println(resposta);
	}
	
	@Test
	void testExercicio6() {
		System.out.println("Exercicio 6");
		var resposta = g.isNulo(this.g);
		System.out.println(resposta);
	}
	
	@Test
	void testExercicio7() {
		System.out.println("Exercicio 7");
		var resposta = g.isCompleto(this.g);
		System.out.println(resposta);
	}
	
	@Test
	void testExercicio8() {
		System.out.println("Exercicio 8");
		var resposta = g.isConexo(this.g);
		System.out.println(resposta);
	}
	
	

	

}
