package trabalhoGrafos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class Grafo {
	
	private ArrayList<Aresta> arestas = new ArrayList<Aresta>();
	private ArrayList<Vertice> vertices = new ArrayList<Vertice>();
	
///////////////////////// Metodos para criar o grafo /////////////////////////////////

	public int addVertice(String nome){
		int i= this.posicaoVertice(nome); 
		
		if(i==this.vertices.size()){
			this.vertices.add(new Vertice(nome));
			return (this.vertices.size() - 1);
		}
		
		return i;
	}
	// Para ver se eu encontro 
	public int posicaoVertice(String nome){
		int i;
		
		for (i=0; i<this.vertices.size() ; i++)
			if (this.vertices.get(i).getNome().equals(nome))
				return i;
		
		//se nao encontrar retorna o tamanho da lista vertices
		return this.vertices.size();
	
	}
	
	public Vertice acharVertice(String nome){
		return this.vertices.get(this.posicaoVertice(nome));
	}
	
	public void addAresta(int peso, String origem, String destino, boolean direcionado){
		int i,j,k;
		
		//adiciona vertices e retorna posicao
		i = this.addVertice(origem);
		j = this.addVertice(destino);
		
		//adiciona aresta na lista
		Aresta a = new Aresta(peso,
				this.vertices.get(i),
				this.vertices.get(j));
	
		this.arestas.add(a);
		k = this.arestas.size();
		
		//adiciona aresta na lista de arestas incidentes em cada vertice
		this.vertices.get(i).addIncidentes(this.arestas.get(k-1));
		this.vertices.get(j).addIncidentes(this.arestas.get(k-1));
		
		if(direcionado == false)
			addAresta(peso,destino,origem,true);
		
	}
	public void listArestas() {
		for (Aresta aresta : arestas) {
			System.out.println("Peso "+aresta.getPeso()+" Origem "+aresta.getOrigem().getNome()+" Destino "+aresta.getDestino().getNome());
		}
	}
////////////////////////////////////// Quest�o 1 //////////////////////////////////////
	public boolean isAdjacente (Vertice v1, Vertice v2) { 
		v1 = this.acharVertice(v1.getNome());
		v2 = this.acharVertice(v2.getNome());
		return v1.isVizinho(v2);
	}	
////////////////////////////////////// Quest�o 2 //////////////////////////////////////
	public int getGrau (Vertice v1) { 
		Vertice vProcurar = acharVertice(v1.getNome());
		
		return vProcurar.grauVertice();
	}	
////////////////////////////////////// Quest�o 3 //////////////////////////////////////	
	public boolean isRegular(Grafo G) {
		if(G.vertices.size() == 1 )
			return true;
		
		for(int i=1;i<vertices.size();i++) {
			if(G.vertices.get(i).grauVertice()!=G.vertices.get(i-1).grauVertice())
				return false;
		}
		return true;
	}
////////////////////////////////////// Quest�o 4 //////////////////////////////////////
	 public boolean isIsolado (Vertice v1) {
		 Vertice vProcurar = acharVertice(v1.getNome());
		 return vProcurar.grauVertice() > 0 ? false : true;
		 
	 }
////////////////////////////////////// Quest�o 5 //////////////////////////////////////	 
	 public boolean isPendente (Vertice v1) { 
		 Vertice vProcurar = acharVertice(v1.getNome());
		 return vProcurar.grauVertice() == 1 ? true : false;
	 }
	 
////////////////////////////////////// Quest�o 6 //////////////////////////////////////	 
	 public boolean isNulo (Grafo G) {
		for (Vertice v : G.vertices) {
			if(v.grauVertice()!= 0)
				return false;
		}
		return true;
	 } 
////////////////////////////////////// Quest�o 7 //////////////////////////////////////	 
	 public boolean isCompleto (Grafo G) { 
		
		 for(int i=0;i<G.vertices.size();i++)
			 for(int k=0;k<G.vertices.size();k++)
					if(!G.vertices.get(i).isVizinho(G.vertices.get(k)) && i!=k)
						return false;
					
		 
		 return true;
	 }
////////////////////////////////////// Quest�o 8 //////////////////////////////////////	
	 public boolean isConexo (Grafo G) {
		 
		 for(int i=0;i<G.vertices.size();i++) {
			 for(int k=1;k<G.vertices.size();k++) {
				 boolean conecta = false;
				 if(i!=k) {
				 conecta(G.vertices.get(i),G.vertices.get(k),conecta);
				 }else if(conecta == false)
					 	return false;
			 } 
		 }

		 return true;
	 }
	 
	 public void conecta(Vertice o, Vertice d,boolean conect) {
		 if(o.isVizinho(d))
			 conect = true;
		 
		 for(int i=0;i<o.getVizinhos().size();i++) {
			System.out.println(o.getVizinhos().size());
			 conecta(o.getVizinhos().get(i),d,conect);
			 
		 }
	 }
}
