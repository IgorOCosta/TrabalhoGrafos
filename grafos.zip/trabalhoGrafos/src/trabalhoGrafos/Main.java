package trabalhoGrafos;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Grafo g = new Grafo();
		g.addVertice("1");
		g.addVertice("2");
		g.addVertice("3");
		g.addVertice("4");
	
	}

}
