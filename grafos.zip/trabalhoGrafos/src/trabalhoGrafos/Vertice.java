package trabalhoGrafos;

import java.util.ArrayList;

public class Vertice {
	private String nome;
	private ArrayList<Aresta> incidentes = new ArrayList<Aresta>();
	private ArrayList<Vertice> vizinhos = new ArrayList<Vertice>();
	
	

	public Vertice(String nome){
		this.setNome(nome);
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	

	public ArrayList<Aresta> getIncidentes() {
		return incidentes;
	}
	
	public void addIncidentes(Aresta incide) {
		this.incidentes.add(incide);
		
		//adicionando vizinhos a lista
		
		//esse if � pq se existe uma aresta com esse nome ela j� tem q ta incluida
		
		// se a origem da aresta nao for esse vertice
		if ( (incide.getOrigem().getNome().equals(this.getNome())) &&
				(!this.isVizinho(incide.getDestino())) ){// o vizinho dessa nao for o destino da aresta
			
			this.addVizinhos(incide.getDestino());
			//se a origem nao for esse vertice e n�o for a origem vizinho dessa aresta
		}else if ( (incide.getDestino().getNome().equals(this.getNome())) &&
				(!this.isVizinho(incide.getOrigem())) ){
			
			this.addVizinhos(incide.getOrigem());
		}
	}
	
	public void addVizinhos(Vertice vizinho) {
		this.vizinhos.add(vizinho);
	}

	public ArrayList<Vertice> getVizinhos() {
		return vizinhos;
	}
	
	public boolean isVizinho(Vertice vizinho){
		int i;
		
		for (i=0; i<this.vizinhos.size() ; i++)
			if (this.vizinhos.get(i).getNome().equals(vizinho.getNome()))
				return true;		
		
		return false;
	}
	
	
	public int grauVertice() {
		return this.getVizinhos().size();
	}


}